package com.company.oop.cosmetics.core.contracts;

public interface Engine {

    void start();

}
